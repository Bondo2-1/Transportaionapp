package userspack;
/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */


/**
 *
 * @author mohamed
 */
public class user {
    String userName,mobileNumber,password,email;
    public static int count=0;
    public user(String userName, String mobileNumber,String password,String email){
        this.userName = userName;
        this.mobileNumber = mobileNumber;
        this.password = password;
        this.email = email;
        count++;
    }
    
    public user(String userName, String mobileNumber,String password){
        this.userName = userName;
        this.mobileNumber = mobileNumber;
        this.password = password;
        this.email = null;
    }

    public String getusername(){
        return this.userName;
    }
    public String getPassword(){
        return this.password;
    }

   
}
