package userspack;
/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */


/**
 *
 * @author mohamed
 */
public class rating {
    public client client;
    public int rating;


    public rating(client c ,int r)
    {
        client = c;
        rating = r;
    }

    public String tostring()
    {
        return "rate " + rating +"/n";

    }

}
