package userspack;
import storage.userliststorage;
import storage.userstorage;
import Uber.Uber;

/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */


/**
 *
 * @author mohamed
 */
public class admin extends user{
    userliststorage userStorage = new userliststorage();

    public admin(String userName, String mobileNumber,String password,String email){
        super(userName, mobileNumber,password,email);
    }
    //transformed to use UserStorage instead of TransportMe
    public void addPendingRegistrations(driver driver){
        userStorage.addPendingRegistration(driver);
    }
     public static void suspendUser (String username){
         for( user user : Uber.registeredUsers ) {
             if(user.getusername().equals(username) ){
                 Uber.registeredUsers.remove(user);
                 Uber.suspendedUsers.add(user);
         }
         }
    }
    public static void unSuspendUser(String username) {
        for (user user : Uber.registeredUsers) {
            if (user.getusername().equals(username)) {
                Uber.registeredUsers.add(user);
                Uber.suspendedUsers.remove(user);
            }

        }
    }
    // transformed to use UserStorage instead of TransportMe
    public void listPendingRegistrations(){
        for (driver driver : userStorage.getPendingRegistrations()){
            System.out.println("driver name is :" +driver.getusername());
            System.out.println("driver national id is :" +driver.getNationalID());
            System.out.println("driver driving licence is :" +driver.getDrivingLicense());
            System.out.println("=================================");
        }
    }
    // transformed to use UserStorage instead of TransportMe
    public boolean acceptRegistration(String userName){
        for( user user : userStorage.getPendingRegistrations() ){
            if( user.getusername().equals(userName) ){
                // remove from pending registration
                userStorage.removePendingRegistration( (driver) user );
                // add registration to database
                userStorage.addRegisteredUser(user);
                return true;
            }
        }
        System.out.println("User not found");
        return false;
}
}
